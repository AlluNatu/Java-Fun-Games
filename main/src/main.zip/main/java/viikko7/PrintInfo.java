package viikko7;

public interface PrintInfo {
    String getInformation();
}
